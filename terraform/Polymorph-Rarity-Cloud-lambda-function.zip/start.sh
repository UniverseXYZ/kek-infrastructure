go run cmd/*.go
